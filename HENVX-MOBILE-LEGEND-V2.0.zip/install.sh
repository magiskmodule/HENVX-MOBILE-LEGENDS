SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

ui_print ""
ui_print "
╭━╮╭━╮╱╱╭╮╱╱╭╮╱╱╱╭╮╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╭╮
┃┃╰╯┃┃╱╱┃┃╱╱┃┃╱╱╱┃┃╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱┃┃
┃╭╮╭╮┣━━┫╰━┳┫┃╭━━┫┃╱╱╭━━┳━━┳━━┳━╮╭━╯┣━━╮
┃┃┃┃┃┃╭╮┃╭╮┣┫┃┃┃━┫┃╱╭┫┃━┫╭╮┃┃━┫╭╮┫╭╮┃━━┫
┃┃┃┃┃┃╰╯┃╰╯┃┃╰┫┃━┫╰━╯┃┃━┫╰╯┃┃━┫┃┃┃╰╯┣━━┃
╰╯╰╯╰┻━━┻━━┻┻━┻━━┻━━━┻━━┻━╮┣━━┻╯╰┻━━┻━━╯
╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╭━╯┃
╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╱╰━━╯"
ui_print ""
ui_print " Verison : 2.0 Stabil "
ui_print " Developer : HenVx | Hendi "
ui_print " Support : https://t.me/HenVx1 "
ui_print ""
ui_print " Executed "
ui_print ""
ui_print ""
ui_print ""

cp -af $TMPDIR/common/uninstall.sh $MODPATH/uninstall.sh > /dev/null 2>&1
ui_print "Installation take some time"
ui_print "Please wait if stuck"
ui_print "Its normal"
cmd package force-dex-opt com.mobile.legends > /dev/null 2>&1