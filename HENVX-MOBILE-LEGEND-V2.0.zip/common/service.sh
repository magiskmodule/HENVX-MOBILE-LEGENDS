#!/system/bin/sh
check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 666 "$1"
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}

sleep 20
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done

nohup MLBB > /dev/null &

chmod 000 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu2/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu3/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq

chmod 000 /sys/devices/system/cpu/cpu0/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu1/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu2/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu3/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu4/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu5/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu6/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu7/cpu_capacity

chmod 000 /sys/devices/system/cpu/cpu0/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu1/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu2/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu3/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu4/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu5/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu6/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu7/topology/physical_package_id

echo 0 > /sys/devices/system/cpu/cpu0/core_ctl/enable

echo 2560,5120,11520,25600,35840,38400 > /sys/module/lowmemorykiller/parameters/minfree

echo "UnityMain, com.mobile.legends, libunity.so, libil2ccp.so, libmain.so" > /proc/sys/kernel/sched_lib_name
echo 550 > /proc/sys/kernel/sched_lib_mask_force

echo "1" > /proc/sys/vm/drop_caches
echo "11" > /proc/sys/vm/dirty_background_ratio
echo "400" > /proc/sys/vm/dirty_expire_centisecs
echo "0" > /proc/sys/vm/page-cluster
echo "20" > /proc/sys/vm/dirty_ratio
echo "0" > /proc/sys/vm/laptop_mode
echo "0" > /proc/sys/vm/block_dump
echo "1" > /proc/sys/vm/compact_memory
echo "3000" > /proc/sys/vm/dirty_writeback_centisecs
echo "0" > /proc/sys/vm/oom_dump_tasks
echo "0" > /proc/sys/vm/oom_kill_allocating_task
echo "1103" > /proc/sys/vm/stat_interval
echo "0" > /proc/sys/vm/panic_on_oom
echo "30" > /proc/sys/vm/swappiness
echo "94" > /proc/sys/vm/vfs_cache_pressure
echo "50" > /proc/sys/vm/overcommit_ratio
echo "25300" > /proc/sys/vm/extra_free_kbytes
echo "64" > /proc/sys/kernel/random/read_wakeup_threshold
echo "128" > /proc/sys/kernel/random/write_wakeup_threshold

find /data/data/com.mobile.legends/cache/* -mtime +1 -delete
find /data/media/0/Android/data/com.mobile.legends/cache/* -mtime +1 -delete

am kill-all